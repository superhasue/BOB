﻿#include <iostream>
#include <Windows.h>
#include <wininet.h>

BOOL InstallService(LPTSTR srvPath);
BOOL UninstallService(void);
BOOL ServiceStart(void);
void ErrorExit(LPTSTR lpszFunction);

void MySetStatus(DWORD dwState, DWORD dwAccept);
void WINAPI ServiceHandler(DWORD fdwControl);

#define srvName "Malservice"
#define mutexName "HGL345"

HANDLE g_ExitEvent;
BOOL g_bPause;
DWORD g_NowState;
DWORD g_NowAccept;
SERVICE_STATUS_HANDLE g_hSrv;

void main(int argc, char *argv[])
{
	char srvPath[MAX_PATH] = ""; //"" 만으로 전체 초기화

	GetCurrentDirectory(MAX_PATH, srvPath);
	strcat(srvPath, "\\");
	strcat(srvPath, "Lab01-02(GUI).exe");

	if (argc == 1)
	{
		return;
	}
	else if (!strcmp(argv[1], "-i"))
	{
		if (InstallService(srvPath) == FALSE)
		{
			UninstallService();
			return;
		}
	}
	else if (!strcmp(argv[1], "-u"))
	{
		UninstallService();
		return;
	}
	else if (!strcmp(argv[1], "-s"))
	{
		if (ServiceStart() == FALSE)
		{
			UninstallService();
			return;
		}
		/*
		//서비스 핸들러를 등록한다.
		g_hSrv = RegisterServiceCtrlHandler(srvName, (LPHANDLER_FUNCTION)ServiceHandler);
		if (g_hSrv == 0) {
			ErrorExit((LPTSTR)("RegisterServiceCtrlHandler"));
			return;
		}
		printf("  Current State: %d\n", g_NowState);
		printf("  ControlsAccepted: %d\n", g_NowAccept);

		//외부에서 서비스 제어 가능하게 하기 //https://sisiblog.tistory.com/165
		//ss.dwControlsAccepted = 0  -> 어떤 제어 요청도 받지 않음
		if (g_NowAccept = 0)
		{
			MySetStatus(SERVICE_CONTROL_CONTINUE, 3);

			printf("  Current State: %d\n", g_NowState);
			printf("  ControlsAccepted: %d\n", g_NowAccept);
		}
		*/
		return;
	}

	return;
}

BOOL InstallService(LPTSTR srvPath)
{
	printf("InstallService\n");
	SC_HANDLE hScm;
	SC_HANDLE hSrv;

	hScm = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS); //SC_MANAGER_CREATE_SERVICE
	if (hScm == FALSE)
	{
		ErrorExit((LPTSTR)("OpenSCManager"));
		return FALSE;
	}

	//서비스 설치 = 레지스터리에 서비스에 대한 정보를 써넣는다.
	hSrv = CreateService(
		hScm,
		srvName, //서비스 고유 이름  
		srvName, //서비스 외부 표시 이름
		SERVICE_ALL_ACCESS, // SERVICE_PAUSE_CONTINUE | SERVICE_CHANGE_CONFIG //SERVICE_ALL_ACCESS SERVICE_START
		SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS, //SERVICE_INTERACTIVE_PROCESS 
		SERVICE_AUTO_START, //SERVICE_DEMAND_START
		SERVICE_ERROR_IGNORE,
		srvPath,
		NULL, NULL, NULL, NULL, NULL);

	if (hSrv == FALSE)
	{
		ErrorExit((LPTSTR)("CreateService"));
		CloseServiceHandle(hSrv);
		return FALSE;
	}

	//CloseServiceHandle(hSrv);
	//CloseServiceHandle(hScm);

	return TRUE;
}
BOOL UninstallService(void)
{
	//https://docs.microsoft.com/ko-kr/windows/desktop/Services/deleting-a-service
	printf("UninstallService\n");
	SC_HANDLE hScm;
	SC_HANDLE hSrv;
	SERVICE_STATUS ss;

	hScm = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS); // full access rights 
	if (hScm == FALSE)
	{
		ErrorExit((LPTSTR)("OpenSCManager"));
		return FALSE;
	}

	hSrv = OpenService(hScm, srvName, SERVICE_ALL_ACCESS); //DELETE
	if (hSrv == FALSE)
	{
		if (GetLastError() != 1060)
			ErrorExit((LPTSTR)("OpenService"));
		CloseServiceHandle(hScm);
		return FALSE;
	}

	if (QueryServiceStatus(hSrv, &ss) == FALSE)
	{
		ErrorExit((LPTSTR)("QueryServiceStatus"));
		DeleteService(hSrv);
		CloseServiceHandle(hSrv);
		CloseServiceHandle(hScm);
		return FALSE;
	}

	if (ss.dwCurrentState != SERVICE_STOPPED)
	{
		ControlService(hSrv, SERVICE_CONTROL_STOP, &ss);
		Sleep(500);
	}

	if (DeleteService(hSrv) == FALSE)
	{
		ErrorExit((LPTSTR)("DeleteService"));
		CloseServiceHandle(hSrv);
		CloseServiceHandle(hScm);
		return FALSE;
	}

	CloseServiceHandle(hSrv);
	CloseServiceHandle(hScm);

	return TRUE;
}
BOOL ServiceStart(void)
{
	printf("ServiceStart\n");
	SC_HANDLE hScm;
	SC_HANDLE hSrv;

	hScm = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS); // SC_MANAGER_CREATE_SERVICE
	if (hScm == FALSE)
	{
		ErrorExit((LPTSTR)("OpenSCManager"));
		return FALSE;
	}

	hSrv = OpenService(hScm, srvName, SERVICE_ALL_ACCESS); //SERVICE_START | SERVICE_QUERY_STATUS
	if (hSrv == FALSE)
	{
		ErrorExit((LPTSTR)("OpenService"));
		CloseServiceHandle(hScm);
		return FALSE;
	}

	SERVICE_STATUS ss;
	if (QueryServiceStatus(hSrv, &ss) == FALSE)
	{
		ErrorExit((LPTSTR)("OpenService"));
		CloseServiceHandle(hSrv);
		CloseServiceHandle(hScm);
		return FALSE;
	}
	printf(" Before :\n");
	printf("  Current State: %d\n", ss.dwCurrentState);
	printf("  ControlsAccepted: %d\n", ss.dwControlsAccepted);


	if (StartService(hSrv, 0, NULL) == FALSE)
	{
		ErrorExit((LPTSTR)("StartService"));
		CloseServiceHandle(hSrv);
		CloseServiceHandle(hScm);
		return FALSE;
	}

	if (QueryServiceStatus(hSrv, &ss) == FALSE)
	{
		ErrorExit((LPTSTR)("OpenService"));
		CloseServiceHandle(hSrv);
		CloseServiceHandle(hScm);
		return FALSE;
	}
	printf(" After :\n");
	printf("  Current State: %d\n", ss.dwCurrentState);
	printf("  ControlsAccepted: %d\n", ss.dwControlsAccepted);
	

	CloseServiceHandle(hSrv);
	CloseServiceHandle(hScm);
	return TRUE;
}

void MySetStatus(DWORD dwState, DWORD dwAccept)
{
	SERVICE_STATUS ss;
	ss.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	ss.dwCurrentState = dwState;
	ss.dwControlsAccepted = dwAccept;
	ss.dwWin32ExitCode = 0;
	ss.dwServiceSpecificExitCode = 0;
	ss.dwCheckPoint = 0;
	ss.dwWaitHint = 0;

	//현재 상태를 보관해 둔다.
	g_NowState = dwState;
	g_NowAccept = dwAccept;
	SetServiceStatus(g_hSrv, &ss);
}

void ErrorExit(LPTSTR lpszFunction)
{
	TCHAR errmsg[1024];
	DWORD dw = GetLastError();

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, dw, 0, errmsg, 1024, NULL);

	printf("%s failed with error %d : %s", lpszFunction, dw, errmsg);
}

